"""Chromatin Studio: configurable exploratory chromatin reaction dynamics."""

__version__ = "0.8.0"
