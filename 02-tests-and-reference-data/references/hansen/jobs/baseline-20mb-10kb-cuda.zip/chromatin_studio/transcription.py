"""Individual polymerases and passive RNA particles in reduced units.

This optional module leaves the legacy count model untouched when disabled.
Nascent RNA is attached to its polymerase; released RNA is a point particle,
not an RNA chain. The same soft harmonic nuclear wall used for chromatin
confines RNA. Processing depends on the RNA position, with a piecewise-frozen
local hazard during each Brownian/reaction substep. This is an operator-split
spatial model, not an exact simulation of diffusion across a reactive boundary.
"""

import math

import numpy as np


_TOTAL_KEYS = ("live", "nascent", "unprocessed", "mature", "initiated",
               "completed", "degraded", "blocked_initiations")


def disabled_transcription_state():
    """Disabled means individual identities/positions are not being simulated."""
    return {"enabled": False, "cap": 0,
            "totals": dict.fromkeys(_TOTAL_KEYS, 0), "transcripts": [], "genes": []}


class ExplicitTranscription:
    """Own live transcripts and synchronize the existing per-gene summaries."""

    def __init__(self, sim):
        self.sim = sim
        self.config = sim.config.get("transcription", {})
        self.cap = int(self.config.get("max_transcripts", 2000))
        self.transcripts = {}
        self.serial = 0
        self.degraded = {g["config"]["id"]: 0 for g in sim.genes}
        self.blocked = {g["config"]["id"]: 0 for g in sim.genes}
        self.gene_by_id = {g["config"]["id"]: g for g in sim.genes}

    def _coordinate(self, bead_position, spec):
        # Each bead represents a genomic interval. The final interval is
        # represented spatially by the final gene bead, including release.
        p = float(np.clip(bead_position, int(spec["start"]), int(spec["end"])))
        left = int(math.floor(p))
        right = min(left + 1, int(spec["end"]))
        return ((1 - (p - left)) * self.sim.positions[left]
                + (p - left) * self.sim.positions[right]).copy()

    def _speed(self, spec, position):
        speed = float(spec.get("elongation_rate", 0))
        if getattr(self.sim, "nucleosomes_enabled", False):
            bead = min(int(math.floor(position)), int(spec["end"]))
            if self.sim.nucleosome_occupied[bead]:
                speed *= float(spec.get("occupied_elongation_multiplier", 1))
        return speed

    def _new_nascent(self, gene, time):
        self.serial += 1
        spec = gene["config"]
        record = {"id": f"rna-{self.serial}", "gene_id": spec["id"],
                  "polymerase_id": f"pol-{self.serial}", "state": "nascent",
                  "bead_position": float(spec["start"]), "length_nt": 0.0,
                  "position": self._coordinate(spec["start"], spec),
                  "paused": False, "initiated_time": float(time),
                  "released_time": None, "processed_time": None}
        self.transcripts[record["id"]] = record
        gene["initiated"] += 1
        return record

    def _move_polymerase(self, record, spec, active_time):
        """Traverse each bead at its own speed; return time consumed to finish."""
        remaining = float(active_time)
        end = int(spec["end"]) + 1
        while remaining > 0 and record["bead_position"] < end:
            p = record["bead_position"]
            speed = self._speed(spec, p)
            if speed <= 0:
                return active_time
            boundary = min(math.floor(p) + 1, end)
            needed = (boundary - p) / speed
            if needed <= remaining:
                record["bead_position"] = float(boundary)
                remaining -= needed
            else:
                record["bead_position"] = p + speed * remaining
                remaining = 0.0
        return active_time - remaining

    def _advance_nascent(self, record, spec, dt, start_time):
        """Exact pause/resume events and piecewise-constant elongation speeds."""
        elapsed = 0.0
        end = int(spec["end"]) + 1
        while elapsed < dt:
            rate = float(spec.get("resume_rate", 1) if record["paused"]
                         else spec.get("pause_rate", 0))
            wait = float(self.sim.rng.exponential(1 / rate)) if rate > 0 else math.inf
            segment = min(wait, dt - elapsed)
            if record["paused"]:
                elapsed += segment
            else:
                elapsed += self._move_polymerase(record, spec, segment)
                if record["bead_position"] >= end:
                    record["state"] = "unprocessed"
                    record["paused"] = False
                    record["released_time"] = start_time + elapsed
                    record["position"] = self._coordinate(end, spec)
                    record["length_nt"] = ((end - int(spec["start"]))
                                            * float(self.sim.chrom.get("bp_per_bead", 1000)))
                    record["bead_position"] = None
                    self.gene_by_id[spec["id"]]["completed"] += 1
                    self._advance_free(record, spec, dt - elapsed, start_time + elapsed)
                    return
            if wait < segment + 1e-14 and elapsed < dt:
                record["paused"] = not record["paused"]
        record["length_nt"] = ((record["bead_position"] - int(spec["start"]))
                               * float(self.sim.chrom.get("bp_per_bead", 1000)))
        record["position"] = self._coordinate(record["bead_position"], spec)

    def _processing_rate(self, record, spec):
        rate = float(spec.get("processing_rate", 0))
        # A released RNA must itself enter a speckle. Gene contact alone does
        # not change this rate. Overlapping speckles do not multiply gains.
        for body in self.sim.bodies:
            if (body.get("kind") == "speckle"
                    and np.linalg.norm(record["position"] - np.asarray(body["center"]))
                    <= float(body["radius"])):
                return rate * (1 + float(spec.get("speckle_gain", 0)))
        return rate

    def _diffusion(self, record):
        key = "mature_rna_diffusion" if record["state"] == "mature" else "rna_diffusion"
        return float(self.config.get(key, 0.15 if record["state"] == "mature" else 0.3))

    def _brownian(self, record, dt):
        diffusion = self._diffusion(record)
        if dt <= 0 or diffusion <= 0:
            return
        p = record["position"]
        radial = float(np.linalg.norm(p))
        force = (-30.0 * (radial - self.sim.radius) / radial * p
                 if radial > self.sim.radius else np.zeros(3))
        record["position"] = (p + diffusion * force * dt
                              + math.sqrt(2 * diffusion * dt) * self.sim.rng.normal(size=3))
        if not np.all(np.isfinite(record["position"])):
            raise FloatingPointError("Non-finite RNA position. Reduce the time step or RNA diffusion.")

    def _advance_free(self, record, spec, dt, start_time):
        """Competing processing/decay with no repeated full-step mature decay."""
        max_diffusion = max(float(self.config.get("rna_diffusion", 0.3)),
                            float(self.config.get("mature_rna_diffusion", 0.15)))
        substeps = max(1, int(math.ceil(dt * max_diffusion * 30 / 0.35)))
        if substeps > 1000:
            raise ValueError("RNA diffusion requires more than 1000 integration substeps; reduce dt.")
        h = dt / substeps
        for substep in range(substeps):
            remaining = h
            elapsed = substep * h
            while remaining > 0:
                processing = self._processing_rate(record, spec) if record["state"] == "unprocessed" else 0.0
                decay = float(spec.get("rna_decay_rate", 0))
                total = processing + decay
                wait = float(self.sim.rng.exponential(1 / total)) if total > 0 else math.inf
                interval = min(remaining, wait)
                self._brownian(record, interval)
                elapsed += interval
                remaining -= interval
                if wait >= interval + 1e-14:
                    continue
                # An event exactly at the interval endpoint is harmless;
                # zero waiting times have probability zero for positive rates.
                if total > 0 and wait <= interval:
                    if processing and self.sim.rng.random() < processing / total:
                        record["state"] = "mature"
                        record["processed_time"] = start_time + elapsed
                    else:
                        self.degraded[spec["id"]] += 1
                        del self.transcripts[record["id"]]
                        return

    def _synchronize(self):
        by_gene = {key: [] for key in self.gene_by_id}
        for record in self.transcripts.values():
            by_gene[record["gene_id"]].append(record)
        for key, gene in self.gene_by_id.items():
            records = by_gene[key]
            gene["polymerases"] = [r["bead_position"] for r in records if r["state"] == "nascent"]
            gene["unprocessed"] = sum(r["state"] == "unprocessed" for r in records)
            gene["mature"] = sum(r["state"] == "mature" for r in records)

    def advance(self, dt, rate_reports):
        """Advance existing molecules, then admit new initiation attempts.

        Initiation occurs at the reaction interval endpoint, as in the count
        model. At capacity a hypergeometric lottery allocates the remaining
        slots uniformly among all initiation attempts, preventing gene-order
        bias. Existing molecules are never deleted to make room.
        """
        start = float(self.sim.time)
        nascent_by_gene = {key: [] for key in self.gene_by_id}
        for record in list(self.transcripts.values()):
            if record["state"] != "nascent":
                self._advance_free(record, self.gene_by_id[record["gene_id"]]["config"], dt, start)
            else:
                nascent_by_gene[record["gene_id"]].append(record)
        attempts = []
        for gene in self.sim.genes:
            spec = gene["config"]
            rates = rate_reports[spec["id"]]
            on_rate = float(rates["effective_on_rate"])
            off_rate = float(spec.get("off_rate", 0))
            total = on_rate + off_rate
            if total:
                switch_rate = off_rate if gene["on"] else on_rate
                if self.sim.rng.random() < switch_rate / total * -np.expm1(-total * dt):
                    gene["on"] = not gene["on"]
                    self.sim._event("promoter", spec["id"] + (" ON" if gene["on"] else " OFF"))
            previous_completed = gene["completed"]
            for record in nascent_by_gene[spec["id"]]:
                self._advance_nascent(record, spec, dt, start)
            completed = gene["completed"] - previous_completed
            if completed:
                self.sim._event("transcription", f"{spec['id']}: {completed} completed")
            attempts.append(int(self.sim.rng.poisson(float(rates["effective_initiation_rate"]) * dt))
                            if gene["on"] else 0)
        available = max(0, self.cap - len(self.transcripts))
        total_attempts = sum(attempts)
        remaining_slots = min(available, total_attempts)
        for gene, attempted in zip(self.sim.genes, attempts):
            if not remaining_slots:
                accepted = 0
            elif total_attempts <= remaining_slots:
                accepted = attempted
            else:
                accepted = int(self.sim.rng.hypergeometric(attempted, total_attempts - attempted, remaining_slots))
            total_attempts -= attempted
            remaining_slots -= accepted
            self.blocked[gene["config"]["id"]] += attempted - accepted
            for _ in range(accepted):
                self._new_nascent(gene, start + dt)
        self._synchronize()

    def snapshot(self):
        records = []
        paused_by_gene = dict.fromkeys(self.gene_by_id, 0)
        for value in self.transcripts.values():
            record = dict(value)
            spec = self.gene_by_id[record["gene_id"]]["config"]
            if record["state"] == "nascent":
                record["position"] = self._coordinate(record["bead_position"], spec)
                record["elongation_rate"] = 0.0 if record["paused"] else self._speed(spec, record["bead_position"])
                paused_by_gene[record["gene_id"]] += bool(record["paused"])
            else:
                record["elongation_rate"] = 0.0
            record["position"] = record["position"].tolist()
            records.append(record)
        genes = []
        for gene in self.sim.genes:
            spec = gene["config"]
            genes.append({"id": spec["id"], "nascent": len(gene["polymerases"]),
                          "unprocessed": gene["unprocessed"], "mature": gene["mature"],
                          "initiated": gene["initiated"], "completed": gene["completed"],
                          "degraded": self.degraded[spec["id"]], "blocked_initiations": self.blocked[spec["id"]],
                          "paused_polymerases": paused_by_gene[spec["id"]],
                          "elongation_rate": float(spec.get("elongation_rate", 0)),
                          "occupied_elongation_multiplier": float(spec.get("occupied_elongation_multiplier", 1)),
                          "pause_rate": float(spec.get("pause_rate", 0)), "resume_rate": float(spec.get("resume_rate", 1))})
        totals = {key: sum(g[key] for g in genes) for key in _TOTAL_KEYS if key != "live"}
        totals["live"] = len(records)
        return {"enabled": True, "cap": self.cap, "totals": totals, "transcripts": records, "genes": genes}
