# Chromatin Studio cluster bundle

This is a fresh model run, not a checkpoint of the browser's current state.
Each replica uses `model.seed + replica_index`. The SLURM array requests one
independent replica per task and one GPU per task only for CUDA/OpenCL.

## Prepare the environment on your cluster

Use Python 3.10 or later and your cluster's supported GPU drivers/runtime. Follow
site instructions for environment modules and GPU allocations. From this directory:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-polychrom.txt
```

Do environment installation on a node where your site permits network access.
For offline compute nodes prepare the environment/wheels beforehand. NumPy and
SciPy minimum versions are portable requirements, not an exact environment lock;
the run manifest records actual versions. The optional file pins OpenMM and the
polychrom source commit used during development.

## Verify, then execute

Request a suitable interactive node to check GPU initialization without advancing
the model (this creates a new directory and refuses existing output):

```sh
python -m chromatin_studio.batch --model model.json --job job.json --replica 0 --preflight --output preflight-0
```

On an allocated node, `sh run.sh 0` runs scientific validation followed by replica
0. Repeat with replica indices 0 through 3 for a generic scheduler.
Inspect `submit.slurm`, make a copy, adjust the copy's directives for your site's
GPU/partition/account rules, activate your environment, then submit from this
directory. Keep bundled files unchanged so their integrity checks remain useful:

```sh
cp submit.slurm submit-local.slurm
# Edit submit-local.slurm to match your site's requirements.
sbatch submit-local.slurm
```

GPU directives vary between clusters (for example `--gres=gpu:1` versus `--gpus=1`).
The supplied template uses `--gres=gpu:1`. The scheduler controls device visibility;
do not replace `CUDA_VISIBLE_DEVICES`. Leave `device_index` unset unless the site's
OpenMM configuration requires a logical device from the visible set. Requested
GPU failures stop the job; there is no automatic CPU fallback.

The export does not submit jobs or copy data. Transfer the ZIP or extracted folder
using your cluster's approved file-transfer tool. Keep login details out of the
model. No cluster connection or credentials are required by Chromatin Studio.

## Outputs and limits

Each `results/replica-N/` contains the seeded model, job, a run manifest, streamed
metrics JSONL, optional snapshot JSONL, and an atomically written final state.
Reports record source/configuration hashes, package versions, requested/actual
backend details and completion or failure. Bundle hashes are checked on startup.
Validation reports are stored beside replica directories. A `.lock` directory
prevents duplicate script launches. Failed attempts remain for diagnosis; run a
new attempt in a fresh results directory instead of deleting evidence blindly.
Abrupt termination can leave a manifest marked `running` and an incomplete last
JSONL line; final-state presence and manifest `complete` identify clean completion.

Metrics and sparse snapshots stream to disk; output size still grows with runtime.
Snapshots are inspection data, not restart checkpoints. Coordinates and times
remain in reduced units. A physical mapping, if attached, is preserved in
`model.json`, `physical-units.json`, and each run manifest, with its provenance
and baseline comparison. An absent, synthetic, or needs-review mapping is not
an experimentally established clock. Current particle/transcript
limits remain enforced. Forces, chemistry and RNA diffusion still run on CPU,
so GPU integration alone is not a promise of higher throughput. Pilot first.
The scientific suite detects several implementation/physics regressions; passing
it does not calibrate the biological model or establish timestep convergence for
your chosen parameters.

## Calculate chromatin MSD for calibration

Enable snapshots and choose an interval that resolves the experimental lag
window. After equilibration, compute the MSD of selected chromatin beads:

```sh
python -m chromatin_studio.calibration msd --snapshots results/replica-0/snapshots.jsonl --beads 10,20 --dimension 2 --observable relative_pair --discard-before 0 --output simulation-msd.json
```

Replace bead indices and discard time with your study's actual choices; zero
discard is only command syntax, not an equilibration recommendation. A final
partial snapshot is irregularly spaced: use a step count divisible by the
snapshot interval, or explicitly select the analyzer's final-frame drop option.
Import the resulting curve into Calibrate in the local UI. Match the observable,
dimensions, drift treatment and imaging corrections to the experimental curve.
Keep the baseline mapping fixed when comparing perturbations. Use independent
replicas, longer runs and smaller timesteps to check convergence.
