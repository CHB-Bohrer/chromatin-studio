#!/bin/sh
set -eu
# Run from the extracted bundle; activate a prepared Python environment first.
cd -- "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
REPLICA=${1:-0}
case "$REPLICA" in ''|*[!0-9]*) echo "Replica must be a nonnegative integer." >&2; exit 2;; esac
if [ "$REPLICA" -ge 4 ]; then echo "Replica is outside this job array." >&2; exit 2; fi
export OMP_NUM_THREADS=4
export OPENMM_CPU_THREADS=4
export OPENBLAS_NUM_THREADS=4
export MKL_NUM_THREADS=4
mkdir -p results
# A lock refuses accidental concurrent repeats and also records failed attempts.
if ! mkdir "results/replica-$REPLICA.lock"; then
  echo "Replica already attempted. Keep its results; use a fresh results directory for a new attempt." >&2
  exit 2
fi
# Verify immutable bundle files before running any scientific tests.
python -c "from chromatin_studio.batch import verify_bundle; verify_bundle('.')"
# Scientific checks run on the same allocated node and requested platform.
python -m chromatin_studio.validation --platform CUDA --precision mixed --output "results/validation-$REPLICA.json"
python -m chromatin_studio.batch --model model.json --job job.json --replica "$REPLICA" --output "results/replica-$REPLICA"
